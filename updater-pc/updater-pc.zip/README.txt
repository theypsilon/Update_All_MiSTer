Copyright (c) 2020 José Manuel Barroso Galindo <theypsilon@gmail.com> - License GPL v3
**************************************************************************************

UPDATE ALL || All-in-On MiSTer Updater script for PC (Windows and Linux)
========================================================================
Update All Website:
https://github.com/theypsilon/Update_All_MiSTer

Download the latest version of this script from:
https://github.com/theypsilon/Update_All_MiSTer/blob/master/updater-pc/updater-pc.zip?raw=true

Follow the news on Twitter @josembarroso




INSTRUCTIONS FOR WINDOWS
========================
1. Extract this ZIP into an EMPTY folder.

2. Go to updater-pc folder.

3. (optional) Create the file 'update_all.ini' on that folder with your desired options.
              Check the available options here:
              https://github.com/theypsilon/Update_All_MiSTer#further-configuration

4. Double click on update_all_win.bat (or update_all_win_db9_snac8.bat).

5. The parent folder will be filled with all the files. Copy everything to your MiSTer SD card.




INSTRUCTIONS FOR LINUX
======================
Same, but you would have to run update_all_linux.sh from the CLI instead.
If some command is not available in your system, the script will tell you.
Install it and run the script again.




LICENSE
=======
Update All has a GPL v3 license.

Windows binaries licenses are under *updater-pc/licenses* directory.
- curl https://curl.haxx.se/
- Cygwin https://www.cygwin.com/
- GNU tools https://www.gnu.org/