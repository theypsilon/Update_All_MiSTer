Copyright (c) 2020 José Manuel Barroso Galindo <theypsilon@gmail.com> - License GPL v3
**************************************************************************************

UPDATE ALL || All-in-On MiSTer Updater script for PC (Windows and Linux)
========================================================================
Update All Website:
https://github.com/theypsilon/Update_All_MiSTer

Download the latest version of this script from:
https://github.com/theypsilon/Update_All_MiSTer/blob/master/updater-pc/updater-pc.zip?raw=true

Follow the news on Twitter @josembarroso




INSTRUCTIONS FOR WINDOWS
========================
1. Extract this ZIP into the root of your MiSTer SD card.
   (don't put it in any SD subdirectory, updater-pc directory must reside in its root).

2. Go to updater-pc folder.

3. (optional) Create the file 'update_all.ini' on that folder with your desired options.
              Check the available options here:
              https://github.com/theypsilon/Update_All_MiSTer#further-configuration

4. Double click on update-win.bat




INSTRUCTIONS FOR LINUX
======================
Same, but you would have to run update-linux.sh from the command line instead.




LICENSE
=======
Update All has a GPL v3 license.

Windows binaries licenses are under *updater-pc/licenses* directory.
- curl https://curl.haxx.se/
- Cygwin https://www.cygwin.com/
- GNU tools https://www.gnu.org/