#!/bin/bash
# Copyright (c) 2020 José Manuel Barroso Galindo <theypsilon@gmail.com>

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# You can download the latest version of this script from:
# https://github.com/theypsilon/Updater_All_MiSTer

# Version 1.1 - 2020-06-18 - Added updater-pc, LLAPI Updater, usb0 support, speed optimizations...
# Version 1.0 - 2020-06-07 - Initial commit

set -euo pipefail

# ========= OPTIONS ==================
CURL_RETRY="--connect-timeout 15 --max-time 120 --retry 3 --retry-delay 5 --silent --show-error"
ALLOW_INSECURE_SSL="true"

# ========= CODE STARTS HERE =========
export UPDATE_ALL_OS="${1:-LINUX}"
export UPDATE_ALL_PC_UPDATER="true"

ENCC_OPTION="${2:-}"
if [[ "${ENCC_OPTION}" == "ENCC_FORKS" ]] ; then
    export UPDATE_ALL_PC_UPDATER_ENCC_FORKS="true"
fi

if [[ "${UPDATE_ALL_OS}" == "LINUX" ]] && ! which curl >/dev/null ; then
    echo "You need to install the following commands: curl"
    exit 1
fi

ORIGINAL_SCRIPT_PATH="/tmp/update_all.sh"
INI_PATH="update_all.ini"
if [[ -f "${INI_PATH}" ]] ; then
    TMP=$(mktemp)
    dos2unix < "${INI_PATH}" 2> /dev/null | grep -v "^exit" > ${TMP} || true
    set +u
    source ${TMP}
    set -u
    rm -f ${TMP}
fi

set +e
SSL_SECURITY_OPTION=""
curl ${CURL_RETRY} "https://github.com" > /dev/null 2>&1
case $? in
    0)
        ;;
    60) ;&
    77)
        if [[ "${ALLOW_INSECURE_SSL}" == "true" ]]
        then
            SSL_SECURITY_OPTION="--insecure"
        else
            echo "CA certificates need"
            echo "to be fixed for"
            echo "using SSL certificate"
            echo "verification."
            echo "Please fix them i.e."
            echo "using security_fixes.sh"
            exit 2
        fi
        ;;
    *)
        echo "No Internet connection"
        exit 1
        ;;
esac
set -e

SCRIPT_PATH="${ORIGINAL_SCRIPT_PATH}"
rm ${SCRIPT_PATH} 2> /dev/null || true

if [[ "${DEBUG_UPDATER:-false}" != "true" ]] || [ ! -f dont_download.sh ] ; then
    REPOSITORY_URL="https://github.com/theypsilon/Update_All_MiSTer"
    echo "Downloading"
    echo "${REPOSITORY_URL}"
    echo ""

    curl \
        ${CURL_RETRY} \
        ${SSL_SECURITY_OPTION} \
        --fail \
        --location \
        -o "${SCRIPT_PATH}" \
        "${REPOSITORY_URL}/blob/master/dont_download.sh?raw=true"

else
    cp dont_download.sh ${SCRIPT_PATH}
fi

sed -i 's/\/media\/fat/\.\./g ' ${SCRIPT_PATH}
if [[ "${UPDATE_ALL_OS}" == "WINDOWS" ]] ; then
    sed -i 's/#!\/bin\/bash/#!bash/g ' ${SCRIPT_PATH}
fi
chmod +x ${SCRIPT_PATH}

export CURL_RETRY
export ALLOW_INSECURE_SSL
export SSL_SECURITY_OPTION
export EXPORTED_INI_PATH="${INI_PATH}"

EXIT_CODE=0

if ! ${SCRIPT_PATH} ; then
    echo
    echo "Script ${ORIGINAL_SCRIPT_PATH} failed!"
    echo

    EXIT_CODE=1
fi

rm ${SCRIPT_PATH}

exit ${EXIT_CODE}
